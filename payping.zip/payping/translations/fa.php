<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{payping}prestashop>payping_13540818d09c750686fb5f357ae7ea6e'] = 'افزونه پرداخت پی‌پینگ';
$_MODULE['<{payping}prestashop>payping_d7434a4fc8ef62affd2d8d6bbb3e28ec'] = ' پرداخت آنلاین با درگاه پی‌پینگ';
$_MODULE['<{payping}prestashop>payping_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'آیا برای پاک کردن اطلاعات مطمئن هستید؟';
$_MODULE['<{payping}prestashop>payping_e2d93539acef2afbbadf8542351fb2b4'] = 'استفاده از ارز برای این ماژول غیر فعال هست.';
$_MODULE['<{payping}prestashop>payping_6672b4ac37898a0cc4c37f6b3bfb226c'] = 'شما برای استفاده از درگاه پی‌پینگ می بایست کد توکن درگاه خود را در تنظیمات ماژول وارد کنید.';
$_MODULE['<{payping}prestashop>payping_c888438d14855d7d96a2724ee9c306bd'] = 'تنظیمات دخیره شد.';
$_MODULE['<{payping}prestashop>payping_b4740c9e4dd0751ea682fd81d627dee2'] = 'کد توکن درگاه خود را وارد نمایید :';
$_MODULE['<{payping}prestashop>payping_5d78ae78252395e552b7e7ed92b7ce25'] = 'واحد پولی شما بر حسب ریال یا تومان؟ (در صورتی که ریال می باشد عدد 10 و در غیر این صورت شماره 1 را وارد کنید.)';
$_MODULE['<{payping}prestashop>payping_17857bb7e0e4a22fa99900af223a03f9'] = 'دخیره کن!';
$_MODULE['<{payping}prestashop>payping_2a304a1348456ccd2234cd71a81bd338'] =  _PS_BASE_URL_.__PS_BASE_URI__;
$_MODULE['<{payping}prestashop>payping_da306a1106368f4dec637b9c376f6cbc'] = ' مشکلی وجود دارد! شرح خطا :';
$_MODULE['<{payping}prestashop>payping_8bbea2c85e130f632369e7305aa1cdfa'] = ' تراکنش ناموفق بود- شرح خطا : عدم وجود کد ارجاع';
$_MODULE['<{payping}prestashop>payping_6585d9032a8dc4539e89237937549739'] = ' مشکلی وجود دارد! شرح خطا سمت برنامه شما :';
$_MODULE['<{payping}prestashop>payping_2ea624d388b73c5ad7976bbb9d758a4f'] = 'در حال انتقال ...';
$_MODULE['<{payping}prestashop>payping_4f4adcbf8c6f66dcfc8a3282ac2bf10a'] = 'آیتم درخواستی مورد نظر موجود نمی‌باشد';
$_MODULE['<{payping}prestashop>payping_bbf94b34eb32268ada57a3be5062fe7d'] = 'دسترسی غیر مجاز';
$_MODULE['<{payping}prestashop>payping_816b112c6105b3ebd537828a39af4818'] = 'عدم دسترسی';
$_MODULE['<{payping}prestashop>payping_285e19f20beded7d215102b49d5c09a0'] = 'سرور در حال حاضر قادر به پاسخگویی نمی‌باشد';
$_MODULE['<{payping}prestashop>payping_cee631121c2ec9232f3a2f028ad5c89b'] = 'مشکلی در سرور رخ داده است';
$_MODULE['<{payping}prestashop>payping_18d8042386b79e2c279fd162df0205c8'] = 'مشکلی در ارسال درخواست وجود دارد';
$_MODULE['<{payping}prestashop>payping_18d8042386b79e2c279fd162df0205c8'] = 'مشکلی در ارسال درخواست وجود دارد';
$_MODULE['<{payping}prestashop>payping_3644a684f98ea8fe223c713b77189a77'] = 'عملیات با موفقیت انجام شد';
$_MODULE['<{payping}prestashop>payping_69cc5117a24818670405f9b4c831302a'] = 'تراکنش ناموفق بود- شرح خطا : ';
$_MODULE['<{payping}prestashop>payping_8fad3b00fc3d45d230c28f0b0e331ea2'] = ' تراکنش ناموفق بود- شرح خطا سمت برنامه شما : ';
$_MODULE['<{payping}prestashop>payping_9df5f41a77fa2417113c808751fbfff0'] = 'متافسانه سامانه قادر به دریافت کد پیگیری نمی باشد! نتیجه درخواست : ';
$_MODULE['<{payping}prestashop>payment_1e5cb4ae1bee1388a97de568a3a5b691'] = ' پرداخت آنلاین با درگاه پی‌پینگ';
$_MODULE['<{payping}prestashop>payment_2a304a1348456ccd2234cd71a81bd338'] =  _PS_BASE_URL_.__PS_BASE_URI__;
$_MODULE['<{payping}prestashop>payment_e29dedb458920c450afbafb1685a25d3'] = ' پرداخت با کارتهای اعتباری / نقدی بانک های عضو شتاب توسط دروازه پرداخت پی‌پینگ ';


return $_MODULE;